//: Playground - noun: a place where people can play


/*
 Constants
 Variables
 Data Types
 Operators
 Collection Types - Array, Dictionary, Set
 Control Flow
 Tuples
 Xcode set up
 Bitbucket account set up/github
 */

//constant
let x = 10 //type inference

//explicitly type

let y : Int = 20 //type annotation : datatype




//variable
var z = 40
z = 50

//tyep safe
let l = "Alok"

let one = "Hello"
let two = "Good Morning"

let m = one + two

//tuple - compound data type
//uses - multiple return type from function
let aTuple = (5, 2.0, true, [1,2,3], [1.0, 2.0])
print(aTuple.0)
print(aTuple.1)
print(aTuple.2)

var atupleMember = aTuple.3
var finalObj = atupleMember[1] //[] = subscripts

print(finalObj)

func dateMonthYear() -> (Int, String, Int){
  let date = 22
  let month = "JUN"
  let year = 2018
  
  return (date, month, year)
  
}


func wada() -> (Int, Bool,Double){
    let ganda = 11
    let check = false
    let aFloat = 3.043
    
    return (ganda, check, aFloat)
}


let dataTuple = dateMonthYear()
let date = dataTuple.0
let month = dataTuple.1
let year = dataTuple.2

//dat types
//collection types
//- Array  - ordered, index, acces by indexes
//Dictionar - key value, unordered - ["key" : value] example - ["kName" : "alok"]
//Set - unordered, unique - usage - we want to create a collection of SSN(social security number, so they must be unique)
//String from swift 4.0

//explicit Int Array
let array1 : [Int] = [1, 2, 3]
//type inference array
let array2 = [1,2,3]

//float
let array3 : [Float] = [1, 2, 3]
print(array3)

//string array
let array4 : [String] = ["alok", "aditya", "yash", "ritu", "xin", "nathan"]

//any
let hetrogeniousArray : [Any] = [1, true, 2.0, "aString", ["name" : 9]]

//gotcha
var againhetrogeniousArray : [Any] = [1, true, 2.0, "aString", ["key" : 9]]
againhetrogeniousArray.append("good morning")
print(againhetrogeniousArray)

//an empty array
let oneMoreArray = [Int]()

var EnptyArr = [Int]()
print(oneMoreArray)

//an empty array of dictionaries
let yetAnotherArray = [[String : Any]]()

let Arr = [String : Any]()

//tuple
let tupleArray = [(Int, Int, Int)]()

let tupleArr = [(Int, Double, Float)]()

//<> angle brackets

var arr4 = Array<Int>()
arr4.append(2)

var anARRAY = Array<Double>()
anARRAY.append(34.55)
anARRAY.append(21.34)
anARRAY.remove(at: 0)
print(anARRAY)



var arr9 = Array<Double>()

let arr5 = Array<Float>()
let arr6 = Array<String>()
let arr7 = Array<Bool>()

//use suscript for acessing element by index[]
//use append(paramater) for adding object
againhetrogeniousArray[1]


againhetrogeniousArray.remove(at: 0)
print(againhetrogeniousArray.count)


//notes
var arwithcap = Array<Int>()
arwithcap.reserveCapacity(2)
arwithcap.append(1)
arwithcap.append(2)

print(arwithcap)

//repeating
let repeatEx = Array(repeating: 1, count: 5)
let repret = Array(repeating: "simon", count: 5)
print(repeatEx)

//Dictionary
var aDict = ["keyName" : "aditya", "keyHobby" : "Chess"]

var bDict = ["lastName": "Venom", "firstname": "Simon"]
let lName = bDict["lastName"]

let name = aDict["keyName"]
let hobby = aDict["keyHobby"]


//nil coalescing operator
print(name ?? "John")

let obj = name ?? "John"
print(hobby ?? "ListeningMusic")

//set values
aDict["keyName"] = "Amit"
print(aDict)

print(aDict.keys)
print(aDict.values)




//optional
//most ontersesting feature in swift
//technically optionals are enums with two cases none and some
//in simple languae a optional can have some value or nil
//uses 1.init something with nil 2.getting some data(person data) from server where there might be som einfo missing
//optional must be var

//we must unwrap optional befor euse
//we 5-6 ways of unwrapping it
   //-forceunwrapping
   // - nil coalescing
   //optional binding (if let)
   //optional chaining
   //switch (very logical) way - as optional are enum we can acces it's acces case for value
   //gurad let


var aOptional : Int?
print(aOptional)

//aOptional = 5

print(aOptional)

if aOptional != nil{
  
  let finalOutPut = 2 + aOptional!//unwrapping with ! operator, aOptional! , called force unwrap

}else{
  print("it is nil")
}



//
var anOptional : Float?
print(aOptional)

anOptional = 2.0

let value = anOptional ?? 0.0//unwrapping with ??
//comparison possible Int vs Int?

var stringOptional : String? = "Alok"

//optional binding
/*
 
 if let unwrap = yourOptionalVar{
 
 //her euse unwrap
 }
 else{
 
 }
 
 */
if let unwarpValue = stringOptional{
  
  let strGreeting = "Good Morning" + " " + unwarpValue
  print(strGreeting)
  
}else{
  print("stringOptional is nil")
}


// familiar with github, branches, merge, pull request, create a new branch(check from finder),


let name1: String? = nil
let unwrappedName = name1 ?? "Anonymous"


print("Hello, \(name1 ?? "Anonymous")!")


